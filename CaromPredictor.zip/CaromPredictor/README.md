# CaromPredictor

Ball trajectory prediction mod for **Carrom Pool by Miniclip**.

Analyzed from: `libgame-CARROM-GooglePlay-Gold-Release-Module-1378.so`

---

## How it works

```
Game Memory ──► MemoryManager (C++)
                    │
                    ▼
              Prediction Engine ──► Physics Simulation
                    │
                    ▼
              NativeBridge (JNI) ──► PredictionView (Kotlin)
                    │
                    ▼
              Screen Overlay ──► Lines drawn on game
```

## Build (GitHub Actions)

1. Push code to GitHub
2. Actions automatically builds APK
3. Download from Actions → Artifacts

## Inject into Carrom Pool APK

### Step 1 — Decompile both APKs
```bash
apktool d CaromPredictor.apk -o predictor
apktool d CaromPool.apk      -o pool
```

### Step 2 — Copy Smali classes
```
predictor/smali/  →  pool/smali_classes5/
```

### Step 3 — Copy native library
```
predictor/lib/arm64-v8a/libcarompredictor.so
    →
pool/lib/arm64-v8a/libcarompredictor.so
```

### Step 4 — Inject launch code
Open `pool/smali.../CarromGameActivity.smali`, find `onCreate`, paste before `return-void`:
```smali
sget-object v0, Lcom/iwex/carompredictor/presentation/activity/LauncherActivity;->Companion:Lcom/iwex/carompredictor/presentation/activity/LauncherActivity$Companion;
move-object v1, p0
check-cast v1, Landroid/content/Context;
invoke-virtual {v0, v1}, Lcom/iwex/carompredictor/presentation/activity/LauncherActivity$Companion;->launch(Landroid/content/Context;)V
```

### Step 5 — Add to AndroidManifest.xml
```xml
<uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW"/>
<service android:name="com.iwex.carompredictor.presentation.service.PredictorService"
         android:enabled="true" android:exported="false"/>
<activity android:name="com.iwex.carompredictor.presentation.activity.LauncherActivity"/>
```

### Step 6 — Recompile
```bash
apktool b pool -o CaromPool_modded.apk
```

---

## Disclaimer
Educational purposes only.
