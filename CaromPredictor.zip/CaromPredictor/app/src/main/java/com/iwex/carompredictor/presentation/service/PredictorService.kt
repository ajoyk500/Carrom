package com.iwex.carompredictor.presentation.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.view.WindowManager
import android.widget.Toast
import com.iwex.carompredictor.data.NativeBridge
import com.iwex.carompredictor.presentation.view.PredictionView

class PredictorService : Service() {

    private val windowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private var predictionView: PredictionView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val screenW = intent?.getFloatExtra(KEY_SCREEN_W, 1080f) ?: 1080f
        val screenH = intent?.getFloatExtra(KEY_SCREEN_H, 1920f) ?: 1920f
        val boardX  = intent?.getFloatExtra(KEY_BOARD_X,  0f)    ?: 0f
        val boardY  = intent?.getFloatExtra(KEY_BOARD_Y,  420f)  ?: 420f
        val boardW  = intent?.getFloatExtra(KEY_BOARD_W,  1080f) ?: 1080f
        val boardH  = intent?.getFloatExtra(KEY_BOARD_H,  1080f) ?: 1080f

        NativeBridge.nativeInitialize()
        NativeBridge.nativeSetTablePos(screenW, screenH, boardX, boardY, boardW, boardH)

        setupOverlay()
        Toast.makeText(this, "CaromPredictor ✓", Toast.LENGTH_SHORT).show()
        return START_NOT_STICKY
    }

    private fun setupOverlay() {
        val view = PredictionView(this)
        windowManager.addView(view, view.layoutParams)
        predictionView = view
    }

    override fun onDestroy() {
        super.onDestroy()
        predictionView?.let {
            it.stopRefresh()
            windowManager.removeView(it)
        }
        predictionView = null
        NativeBridge.nativeExit()
    }

    companion object {
        const val KEY_SCREEN_W = "screen_w"
        const val KEY_SCREEN_H = "screen_h"
        const val KEY_BOARD_X  = "board_x"
        const val KEY_BOARD_Y  = "board_y"
        const val KEY_BOARD_W  = "board_w"
        const val KEY_BOARD_H  = "board_h"

        fun newIntent(
            context: Context,
            screenW: Float, screenH: Float,
            boardX:  Float, boardY:  Float,
            boardW:  Float, boardH:  Float
        ) = Intent(context, PredictorService::class.java).apply {
            putExtra(KEY_SCREEN_W, screenW)
            putExtra(KEY_SCREEN_H, screenH)
            putExtra(KEY_BOARD_X,  boardX)
            putExtra(KEY_BOARD_Y,  boardY)
            putExtra(KEY_BOARD_W,  boardW)
            putExtra(KEY_BOARD_H,  boardH)
        }
    }
}
