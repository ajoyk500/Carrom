// CaromPredictor - MemoryManager.cpp
#include "MemoryManager.h"
#include "Offsets.h"
#include "../data/GameConstants.h"

#include <unistd.h>
#include <cstdio>
#include <cstdlib>
#include <cstring>

// ── Static members ────────────────────────────────────────────────────────────
ADDRESS MemoryManager::gameModuleBase = 0;

ADDRESS MemoryManager::FieldObjects::listBase = 0;
int     MemoryManager::FieldObjects::count    = 0;
ADDRESS MemoryManager::StrikerInfo::base      = 0;
ADDRESS MemoryManager::GameState::base        = 0;

// ── Module discovery ──────────────────────────────────────────────────────────
ADDRESS MemoryManager::findModuleBase(const char* name) {
    FILE* maps = fopen("/proc/self/maps", "rt");
    if (!maps) return 0;

    char    line[512];
    ADDRESS addr = 0;
    while (fgets(line, sizeof(line), maps)) {
        if (strstr(line, name)) {
            addr = (ADDRESS)strtoull(line, nullptr, 16);
            break;
        }
    }
    fclose(maps);
    return addr;
}

bool MemoryManager::initialize() {
    // Wait until game library is loaded
    while (gameModuleBase == 0) {
        gameModuleBase = findModuleBase(Offsets::GAME_LIB_NAME);
        sleep(1);
    }

    // Read global game manager pointer
    ADDRESS gameManagerAddr = 0;
    while (gameManagerAddr == 0) {
        // sharedDirector → scene → gameLayer → carromGameManager
        // We read via the known global offset
        ADDRESS directorPtr = gameModuleBase + Offsets::Globals::SharedDirector;
        ADDRESS director    = read<ADDRESS>(directorPtr);
        if (director == 0) { sleep(1); continue; }

        // Try to reach CarromGameManager via scene graph
        // director->_runningScene (offset ~0x160 in Cocos2d CCDirector)
        ADDRESS scene = read<ADDRESS>(director + 0x160);
        if (scene == 0) { sleep(1); continue; }

        // scene->getChildByTag(GAME_LAYER_TAG) — tag 100 is common
        // For simplicity, use the global AimEvent which is always populated
        ADDRESS aimEventAddr = gameModuleBase + Offsets::Globals::AimEvent;
        if (aimEventAddr != 0) {
            gameManagerAddr = aimEventAddr; // use as sentinel
            break;
        }
        sleep(1);
    }

    FieldObjects::initialize(gameModuleBase);
    StrikerInfo::initialize(gameModuleBase);
    GameState::initialize(gameModuleBase);
    return true;
}

// ── FieldObjects ──────────────────────────────────────────────────────────────
void MemoryManager::FieldObjects::initialize(ADDRESS base) {
    listBase = base + Offsets::Globals::PuckState;
}

void MemoryManager::FieldObjects::refresh() {
    // Re-read count from live proto
    // _gameplay_puck_state has a count field at offset 0x4
    ADDRESS puckStateProto = gameModuleBase + Offsets::Globals::PuckState;
    count = read<int>(puckStateProto + 0x4);
    if (count < 0 || count > MAX_FIELD_OBJECTS) count = TOTAL_PUCKS_COUNT;
}

int MemoryManager::FieldObjects::getPuckCount() {
    refresh();
    return count;
}

Point2D MemoryManager::FieldObjects::getPuckPosition(int index) {
    // Each entry in the puck state list is a FieldEntity pointer
    ADDRESS entryAddr = listBase + 0x10 + (index * 0x8); // pointer array
    ADDRESS entity    = read<ADDRESS>(entryAddr);
    if (entity == 0) return {0.0, 0.0};

    double x = read<double>(entity + Offsets::FieldEntity::X);
    double y = read<double>(entity + Offsets::FieldEntity::Y);
    return {x, y};
}

int MemoryManager::FieldObjects::getPuckType(int index) {
    ADDRESS entryAddr = listBase + 0x10 + (index * 0x8);
    ADDRESS entity    = read<ADDRESS>(entryAddr);
    if (entity == 0) return ERR_TYPE;
    return read<int>(entity + Offsets::FieldEntity::Type);
}

bool MemoryManager::FieldObjects::isPuckOnTable(int index) {
    ADDRESS entryAddr = listBase + 0x10 + (index * 0x8);
    ADDRESS entity    = read<ADDRESS>(entryAddr);
    if (entity == 0) return false;
    return read<bool>(entity + Offsets::FieldEntity::OnTable);
}

Point2D MemoryManager::FieldObjects::getQueenPosition() {
    // Queen is a specific FieldEntity — scan for BallType::QUEEN
    for (int i = 0; i < TOTAL_PUCKS_COUNT; i++) {
        if (getPuckType(i) == BallType::QUEEN) {
            return getPuckPosition(i);
        }
    }
    return {0.0, 0.0};
}

bool MemoryManager::FieldObjects::isQueenOnTable() {
    for (int i = 0; i < TOTAL_PUCKS_COUNT; i++) {
        if (getPuckType(i) == BallType::QUEEN) {
            return isPuckOnTable(i);
        }
    }
    return false;
}

// ── StrikerInfo ───────────────────────────────────────────────────────────────
void MemoryManager::StrikerInfo::initialize(ADDRESS moduleBase) {
    base = moduleBase + Offsets::Globals::StrikerInstance;
}

Point2D MemoryManager::StrikerInfo::getPosition() {
    ADDRESS striker = read<ADDRESS>(base);
    if (striker == 0) return {0.0, 0.0};
    double x = read<double>(striker + Offsets::Striker::X);
    double y = read<double>(striker + Offsets::Striker::Y);
    return {x, y};
}

double MemoryManager::StrikerInfo::getAimAngle() {
    // Read from AimEvent proto which is updated every frame
    ADDRESS aimProto = gameModuleBase + Offsets::Globals::AimEvent;
    return read<double>(aimProto + Offsets::AimEvent::Angle);
}

double MemoryManager::StrikerInfo::getShotPower() {
    ADDRESS aimProto = gameModuleBase + Offsets::Globals::AimEvent;
    return read<double>(aimProto + Offsets::AimEvent::Power);
}

bool MemoryManager::StrikerInfo::isMoving() {
    ADDRESS striker = read<ADDRESS>(base);
    if (striker == 0) return false;
    return read<bool>(striker + Offsets::Striker::IsMoving);
}

// ── GameState ─────────────────────────────────────────────────────────────────
void MemoryManager::GameState::initialize(ADDRESS moduleBase) {
    base = moduleBase + Offsets::Globals::TableState;
}

bool MemoryManager::GameState::isInGame() {
    ADDRESS tableState = read<ADDRESS>(base);
    if (tableState == 0) return false;
    // If table state proto is non-zero it means we're in an active match
    int state = read<int>(tableState + 0x4);
    return state > 0;
}

int MemoryManager::GameState::getPlayerTurn() {
    ADDRESS tableState = read<ADDRESS>(base);
    if (tableState == 0) return 0;
    return read<int>(tableState + 0x8);
}

int MemoryManager::GameState::getLocalPlayer() {
    ADDRESS tableState = read<ADDRESS>(base);
    if (tableState == 0) return 0;
    return read<int>(tableState + 0xC);
}
