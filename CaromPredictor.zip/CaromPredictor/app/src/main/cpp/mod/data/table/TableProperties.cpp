// CaromPredictor - TableProperties.cpp
#include "TableProperties.h"
#include <cmath>

float  TableProperties::sScreenW    = 1080.0f;
float  TableProperties::sScreenH    = 1920.0f;
float  TableProperties::sBoardX     = 0.0f;
float  TableProperties::sBoardY     = 0.0f;
float  TableProperties::sBoardW     = 1080.0f;
float  TableProperties::sBoardH     = 1080.0f;
bool   TableProperties::sInitialized = false;

Point2D    TableProperties::sPockets[POCKET_COUNT];
Point2D    TableProperties::sTableShape[TABLE_SHAPE_SIZE];
ScreenPoint TableProperties::sPocketsScreen[POCKET_COUNT];

void TableProperties::initialize(float screenW, float screenH,
                                  float boardX,  float boardY,
                                  float boardW,  float boardH) {
    sScreenW = screenW; sScreenH = screenH;
    sBoardX  = boardX;  sBoardY  = boardY;
    sBoardW  = boardW;  sBoardH  = boardH;

    // 4 corner pockets — exact corners of the playfield
    sPockets[0] = { -TABLE_HALF_WIDTH,  -TABLE_HALF_HEIGHT }; // Top-Left
    sPockets[1] = {  TABLE_HALF_WIDTH,  -TABLE_HALF_HEIGHT }; // Top-Right
    sPockets[2] = {  TABLE_HALF_WIDTH,   TABLE_HALF_HEIGHT }; // Bottom-Right
    sPockets[3] = { -TABLE_HALF_WIDTH,   TABLE_HALF_HEIGHT }; // Bottom-Left

    // Cache screen positions of pockets
    for (int i = 0; i < POCKET_COUNT; i++) {
        sPocketsScreen[i] = worldToScreen(sPockets[i]);
    }

    buildTableShape();
    sInitialized = true;
}

const Point2D* TableProperties::getPockets() {
    return sPockets;
}

const Point2D* TableProperties::getTableShape() {
    return sTableShape;
}

ScreenPoint* TableProperties::getPocketsInScreen() {
    return sPocketsScreen;
}

ScreenPoint TableProperties::worldToScreen(const Point2D& p) {
    // World origin (0,0) = board center
    float scaleX = sBoardW / TABLE_WIDTH;
    float scaleY = sBoardH / TABLE_HEIGHT;

    float sx = sBoardX + sBoardW * 0.5f + (float)p.x * scaleX;
    float sy = sBoardY + sBoardH * 0.5f + (float)p.y * scaleY;
    return { sx, sy };
}

void TableProperties::buildTableShape() {
    // Build rectangular cushion polygon with corner cut-outs for pockets.
    // Each corner has a small gap (pocket opening) of POCKET_RADIUS width.
    // We generate TABLE_SHAPE_SIZE points going clockwise.

    double hw  = TABLE_HALF_WIDTH;
    double hh  = TABLE_HALF_HEIGHT;
    double pr  = POCKET_RADIUS * 1.2; // slight extra to match game feel

    // Points per side (excluding corners)
    // Sides: Top, Right, Bottom, Left — 4 sides × 10 pts each = 40
    int idx = 0;
    int ptsPerSide = TABLE_SHAPE_SIZE / 4;

    // Top side: left→right (y = -hh)
    for (int i = 0; i < ptsPerSide; i++) {
        double t = (double)i / (ptsPerSide - 1);
        double x = -hw + pr + t * (TABLE_WIDTH - 2.0 * pr);
        sTableShape[idx++] = { x, -hh };
    }
    // Right side: top→bottom (x = hw)
    for (int i = 0; i < ptsPerSide; i++) {
        double t = (double)i / (ptsPerSide - 1);
        double y = -hh + pr + t * (TABLE_HEIGHT - 2.0 * pr);
        sTableShape[idx++] = { hw, y };
    }
    // Bottom side: right→left (y = hh)
    for (int i = 0; i < ptsPerSide; i++) {
        double t = (double)i / (ptsPerSide - 1);
        double x = hw - pr - t * (TABLE_WIDTH - 2.0 * pr);
        sTableShape[idx++] = { x, hh };
    }
    // Left side: bottom→top (x = -hw)
    for (int i = 0; i < ptsPerSide; i++) {
        double t = (double)i / (ptsPerSide - 1);
        double y = hh - pr - t * (TABLE_HEIGHT - 2.0 * pr);
        sTableShape[idx++] = { -hw, y };
    }
}
