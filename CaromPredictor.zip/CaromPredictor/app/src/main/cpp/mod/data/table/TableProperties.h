// CaromPredictor - TableProperties.h
#pragma once
#include "../type/Point2D.h"
#include "../GameConstants.h"

class TableProperties {
public:
    // Called once with screen dimensions so we can convert world→screen
    static void initialize(float screenW, float screenH,
                           float boardX,  float boardY,
                           float boardW,  float boardH);

    static const Point2D*   getPockets();           // 4 corner pocket centers
    static const Point2D*   getTableShape();        // cushion polygon points
    static ScreenPoint       worldToScreen(const Point2D& p);
    static ScreenPoint*      getPocketsInScreen();

private:
    static float sScreenW, sScreenH;
    static float sBoardX,  sBoardY;   // board top-left in screen pixels
    static float sBoardW,  sBoardH;   // board size in screen pixels

    static Point2D  sPockets[POCKET_COUNT];
    static Point2D  sTableShape[TABLE_SHAPE_SIZE];
    static ScreenPoint sPocketsScreen[POCKET_COUNT];

    static bool sInitialized;
    static void buildTableShape();
};
