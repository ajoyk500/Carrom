package com.iwex.carompredictor.crash;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.iwex.carompredictor.R;

public class CrashActivity extends AppCompatActivity {

    public static final String EXTRA_CRASH_LOG = "crash_log";
    public static final String EXTRA_PACKAGE   = "package_name";

    // ── Views ─────────────────────────────────────────────────────────────────
    private TextView   tvCrashLog;
    private TextView   tvErrorType;
    private TextView   tvErrorLine;
    private ScrollView scrollView;
    private LinearLayout cardError;
    private LinearLayout btnCopy;
    private LinearLayout btnRestart;
    private LinearLayout btnClose;
    private ImageView  imgBug;

    private String crashLog    = "";
    private String packageName = "";

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_crash);

        // Parse intent
        if (getIntent() != null) {
            crashLog    = getIntent().getStringExtra(EXTRA_CRASH_LOG);
            packageName = getIntent().getStringExtra(EXTRA_PACKAGE);
            if (crashLog    == null) crashLog    = "No crash log available.";
            if (packageName == null) packageName = getPackageName();
        }

        bindViews();
        parseAndDisplayError();
        setupButtons();
        runEntranceAnimation();
    }

    @Override
    public void onBackPressed() {
        // Block back button — user must choose an action
    }

    // ── View Binding ──────────────────────────────────────────────────────────
    private void bindViews() {
        tvCrashLog  = findViewById(R.id.tv_crash_log);
        tvErrorType = findViewById(R.id.tv_error_type);
        tvErrorLine = findViewById(R.id.tv_error_line);
        scrollView  = findViewById(R.id.scroll_crash);
        cardError   = findViewById(R.id.card_error);
        btnCopy     = findViewById(R.id.btn_copy);
        btnRestart  = findViewById(R.id.btn_restart);
        btnClose    = findViewById(R.id.btn_close);
        imgBug      = findViewById(R.id.img_bug);
    }

    // ── Error Parsing ─────────────────────────────────────────────────────────
    private void parseAndDisplayError() {
        tvCrashLog.setText(crashLog);

        // Extract exception type from first "TYPE :" line
        String errorType = "Unknown Error";
        String errorLine = "";
        for (String line : crashLog.split("\n")) {
            line = line.trim();
            if (line.startsWith("TYPE")) {
                String[] parts = line.split(":");
                if (parts.length > 1) {
                    String full = parts[parts.length - 1].trim();
                    // Extract just the class name (after last dot)
                    int dot = full.lastIndexOf('.');
                    errorType = dot >= 0 ? full.substring(dot + 1) : full;
                }
            }
            if (line.contains("at com.iwex") || line.contains("at com.miniclip")) {
                errorLine = line.replace("at ", "");
                break;
            }
        }

        tvErrorType.setText(errorType);
        tvErrorLine.setText(errorLine.isEmpty() ? "See full log below" : errorLine);
    }

    // ── Buttons ───────────────────────────────────────────────────────────────
    private void setupButtons() {

        // COPY
        btnCopy.setOnClickListener(v -> {
            animateButtonClick(btnCopy);
            ClipboardManager cm = (ClipboardManager)
                getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) {
                cm.setPrimaryClip(ClipData.newPlainText("CrashLog", crashLog));
            }
            showToast("📋 Crash log copied!");
        });

        // RESTART
        btnRestart.setOnClickListener(v -> {
            animateButtonClick(btnRestart);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                Intent launch = getPackageManager()
                    .getLaunchIntentForPackage(packageName);
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(launch);
                }
                finish();
                android.os.Process.killProcess(android.os.Process.myPid());
            }, 300);
        });

        // CLOSE
        btnClose.setOnClickListener(v -> {
            animateButtonClick(btnClose);
            new Handler(Looper.getMainLooper()).postDelayed(() -> {
                finish();
                android.os.Process.killProcess(android.os.Process.myPid());
            }, 300);
        });
    }

    // ── Animations ────────────────────────────────────────────────────────────
    private void runEntranceAnimation() {
        // Bug icon pulse
        imgBug.setAlpha(0f);
        imgBug.setScaleX(0.3f);
        imgBug.setScaleY(0.3f);

        ObjectAnimator fadeIcon  = ObjectAnimator.ofFloat(imgBug, "alpha",  0f, 1f);
        ObjectAnimator scaleXIcon = ObjectAnimator.ofFloat(imgBug, "scaleX", 0.3f, 1f);
        ObjectAnimator scaleYIcon = ObjectAnimator.ofFloat(imgBug, "scaleY", 0.3f, 1f);
        fadeIcon.setDuration(400);
        scaleXIcon.setDuration(400);
        scaleYIcon.setDuration(400);
        fadeIcon.setInterpolator(new DecelerateInterpolator());
        scaleXIcon.setInterpolator(new DecelerateInterpolator());
        scaleYIcon.setInterpolator(new DecelerateInterpolator());

        // Card slide up
        cardError.setTranslationY(80f);
        cardError.setAlpha(0f);
        ObjectAnimator slideCard = ObjectAnimator.ofFloat(cardError, "translationY", 80f, 0f);
        ObjectAnimator fadeCard  = ObjectAnimator.ofFloat(cardError, "alpha", 0f, 1f);
        slideCard.setDuration(450);
        fadeCard.setDuration(450);
        slideCard.setStartDelay(200);
        fadeCard.setStartDelay(200);
        slideCard.setInterpolator(new DecelerateInterpolator());

        // Buttons slide up
        animateViewIn(btnCopy,    500);
        animateViewIn(btnRestart, 600);
        animateViewIn(btnClose,   700);

        AnimatorSet set = new AnimatorSet();
        set.playTogether(fadeIcon, scaleXIcon, scaleYIcon, slideCard, fadeCard);
        set.start();
    }

    private void animateViewIn(View view, long delay) {
        view.setTranslationY(60f);
        view.setAlpha(0f);
        view.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(400)
            .setStartDelay(delay)
            .setInterpolator(new DecelerateInterpolator())
            .start();
    }

    private void animateButtonClick(View view) {
        view.animate()
            .scaleX(0.93f)
            .scaleY(0.93f)
            .setDuration(80)
            .withEndAction(() ->
                view.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(120)
                    .start()
            ).start();
    }

    private void showToast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
