package com.iwex.carompredictor.presentation.view

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import com.iwex.carompredictor.data.NativeBridge

class PredictionView(context: Context) : View(context) {

    // WindowManager layout params — fullscreen non-interactive overlay
    val layoutParams: WindowManager.LayoutParams = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        android.graphics.PixelFormat.TRANSLUCENT
    )

    // ── Paints ────────────────────────────────────────────────────────────────
    private val strikerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = Color.WHITE
        strokeWidth = 4f
        style       = Paint.Style.STROKE
        alpha       = 200
    }
    private val blackPuckPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = Color.parseColor("#333333")
        strokeWidth = 3f
        style       = Paint.Style.STROKE
        alpha       = 180
    }
    private val whitePuckPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = Color.parseColor("#EEEEEE")
        strokeWidth = 3f
        style       = Paint.Style.STROKE
        alpha       = 180
    }
    private val queenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color       = Color.parseColor("#FF3333")
        strokeWidth = 4f
        style       = Paint.Style.STROKE
        alpha       = 220
    }
    private val pocketHitPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color  = Color.parseColor("#00FF88")
        style  = Paint.Style.FILL
        alpha  = 160
    }
    private val pocketMissPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color  = Color.parseColor("#FF4444")
        style  = Paint.Style.FILL
        alpha  = 80
    }

    // ── State ─────────────────────────────────────────────────────────────────
    private var shotData: FloatArray? = null
    private val handler  = Handler(Looper.getMainLooper())
    private val path     = Path()

    // ── Refresh loop (every 33ms ≈ 30fps) ────────────────────────────────────
    private val refreshRunnable = object : Runnable {
        override fun run() {
            val data = NativeBridge.nativeGetShotResult()
            if (data != null) {
                shotData = data
                invalidate()
            }
            handler.postDelayed(this, 33L)
        }
    }

    init {
        setBackgroundColor(Color.TRANSPARENT)
        handler.post(refreshRunnable)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val data = shotData ?: return
        if (data.isEmpty()) return

        var idx = 0

        // ── Section 1: Ball trajectories ────────────────────────────────────
        val drawLines = data[idx++] > 0.5f
        if (drawLines && data.size > idx) {
            val nBalls = data[idx++].toInt()
            repeat(nBalls) {
                if (idx >= data.size) return@repeat
                val ballIndex = data[idx++].toInt()
                val nPts      = data[idx++].toInt()
                if (nPts < 2 || idx + nPts * 2 > data.size) {
                    idx += nPts * 2
                    return@repeat
                }

                val paint = when (ballIndex) {
                    0    -> strikerPaint
                    else -> whitePuckPaint // default; improved below
                }

                path.reset()
                path.moveTo(data[idx], data[idx + 1])
                idx += 2
                for (p in 1 until nPts) {
                    path.lineTo(data[idx], data[idx + 1])
                    idx += 2
                }
                canvas.drawPath(path, paint)
            }
        }

        // ── Section 2: Pocket indicators ────────────────────────────────────
        if (idx < data.size && data[idx++] > 0.5f) {
            val POCKET_COUNT = 4
            repeat(POCKET_COUNT) {
                if (idx + 2 >= data.size) return@repeat
                val hit = data[idx++] > 0.5f
                val px  = data[idx++]
                val py  = data[idx++]
                canvas.drawCircle(px, py, 22f, if (hit) pocketHitPaint else pocketMissPaint)
            }
        }
    }

    fun stopRefresh() {
        handler.removeCallbacks(refreshRunnable)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        stopRefresh()
    }
}
