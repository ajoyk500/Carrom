package com.iwex.carompredictor.presentation.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.iwex.carompredictor.data.NativeBridge
import com.iwex.carompredictor.presentation.view.PredictionView

class PredictorService : Service() {

    private val windowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private var predictionView: PredictionView? = null

    companion object {
        const val KEY_SCREEN_W = "screen_w"
        const val KEY_SCREEN_H = "screen_h"
        const val KEY_BOARD_X  = "board_x"
        const val KEY_BOARD_Y  = "board_y"
        const val KEY_BOARD_W  = "board_w"
        const val KEY_BOARD_H  = "board_h"

        private const val CHANNEL_ID   = "carom_predictor_channel"
        private const val NOTIF_ID     = 1001

        fun newIntent(
            context: Context,
            screenW: Float, screenH: Float,
            boardX: Float,  boardY: Float,
            boardW: Float,  boardH: Float
        ) = Intent(context, PredictorService::class.java).apply {
            putExtra(KEY_SCREEN_W, screenW)
            putExtra(KEY_SCREEN_H, screenH)
            putExtra(KEY_BOARD_X,  boardX)
            putExtra(KEY_BOARD_Y,  boardY)
            putExtra(KEY_BOARD_W,  boardW)
            putExtra(KEY_BOARD_H,  boardH)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val screenW = intent?.getFloatExtra(KEY_SCREEN_W, 1080f) ?: 1080f
        val screenH = intent?.getFloatExtra(KEY_SCREEN_H, 1920f) ?: 1920f
        val boardX  = intent?.getFloatExtra(KEY_BOARD_X,  0f)    ?: 0f
        val boardY  = intent?.getFloatExtra(KEY_BOARD_Y,  420f)  ?: 420f
        val boardW  = intent?.getFloatExtra(KEY_BOARD_W,  1080f) ?: 1080f
        val boardH  = intent?.getFloatExtra(KEY_BOARD_H,  1080f) ?: 1080f

        NativeBridge.nativeInitialize()
        NativeBridge.nativeSetTablePos(screenW, screenH, boardX, boardY, boardW, boardH)

        setupOverlay()
        Toast.makeText(this, "CaromPredictor ON", Toast.LENGTH_SHORT).show()
        return START_STICKY
    }

    private fun setupOverlay() {
        // Remove old view if exists
        predictionView?.let {
            it.stopRefresh()
            windowManager.removeView(it)
        }
        val view = PredictionView(this)
        windowManager.addView(view, view.layoutParams)
        predictionView = view
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "CaromPredictor",
                NotificationManager.IMPORTANCE_LOW
            ).apply { description = "Trajectory prediction overlay" }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CaromPredictor")
            .setContentText("Prediction overlay active")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    override fun onDestroy() {
        super.onDestroy()
        predictionView?.let {
            it.stopRefresh()
            windowManager.removeView(it)
        }
        predictionView = null
        NativeBridge.nativeExit()
    }
}
