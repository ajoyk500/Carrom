package com.iwex.carompredictor.crash

import android.content.Context
import android.content.Intent
import android.os.Build
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * CrashHandler — Global uncaught exception interceptor.
 *
 * Usage (in any Activity.onCreate or Application.onCreate):
 *   CrashHandler.install(context)
 */
class CrashHandler private constructor(
    private val appContext: Context,
    private val defaultHandler: Thread.UncaughtExceptionHandler?
) : Thread.UncaughtExceptionHandler {

    override fun uncaughtException(thread: Thread, throwable: Throwable) {
        try {
            val crashLog = buildCrashReport(thread, throwable)
            val intent = Intent(appContext, CrashActivity::class.java).apply {
                putExtra(CrashActivity.EXTRA_CRASH_LOG, crashLog)
                putExtra(CrashActivity.EXTRA_PACKAGE, appContext.packageName)
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TASK or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
                )
            }
            appContext.startActivity(intent)
        } catch (e: Exception) {
            defaultHandler?.uncaughtException(thread, throwable)
        }
        android.os.Process.killProcess(android.os.Process.myPid())
        System.exit(1)
    }

    companion object {

        fun install(context: Context) {
            val current = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler(
                CrashHandler(context.applicationContext, current)
            )
        }

        fun buildCrashReport(thread: Thread, throwable: Throwable): String {
            val sw = StringWriter()
            val pw = PrintWriter(sw)

            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                .format(Date())

            pw.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            pw.println("  CRASH REPORT — CaromPredictor")
            pw.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            pw.println()
            pw.println("TIME    : $time")
            pw.println("THREAD  : ${thread.name} (id=${thread.id})")
            pw.println()
            pw.println("── DEVICE ───────────────────────────────")
            pw.println("BRAND   : ${Build.BRAND}")
            pw.println("MODEL   : ${Build.MODEL}")
            pw.println("ANDROID : ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            pw.println("ABI     : ${Build.SUPPORTED_ABIS[0]}")
            pw.println()
            pw.println("── EXCEPTION ────────────────────────────")
            pw.println("TYPE    : ${throwable.javaClass.name}")
            pw.println("MESSAGE : ${throwable.message}")
            pw.println()
            pw.println("── STACK TRACE ──────────────────────────")
            throwable.printStackTrace(pw)

            var cause = throwable.cause
            var depth = 0
            while (cause != null && depth < 5) {
                pw.println()
                pw.println("── CAUSED BY ────────────────────────────")
                cause.printStackTrace(pw)
                cause = cause.cause
                depth++
            }

            pw.println()
            pw.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━")
            pw.flush()
            return sw.toString()
        }
    }
}
