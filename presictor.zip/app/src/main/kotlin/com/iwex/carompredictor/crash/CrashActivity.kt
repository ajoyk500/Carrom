package com.iwex.carompredictor.crash

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.method.ScrollingMovementMethod
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class CrashActivity : AppCompatActivity() {

    private lateinit var tvErrorType: TextView
    private lateinit var tvErrorLine: TextView
    private lateinit var tvCrashLog: TextView
    private lateinit var btnCopy: Button
    private lateinit var btnRestart: Button
    private lateinit var btnClose: Button

    private var crashLog    = ""
    private var pkgName     = ""

    // ── dp helper ─────────────────────────────────────────────────────────────
    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        crashLog = intent?.getStringExtra(EXTRA_CRASH_LOG) ?: "No crash log."
        pkgName  = intent?.getStringExtra(EXTRA_PACKAGE)  ?: packageName

        setContentView(buildUI())
        parseAndDisplay()
        setupButtons()
        runEntranceAnimation()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = Unit

    // ══════════════════════════════════════════════════════════════════════════
    //  BUILD UI — fully programmatic, zero XML
    // ══════════════════════════════════════════════════════════════════════════
    private fun buildUI(): ScrollView {

        // ── Root ScrollView ───────────────────────────────────────────────────
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0D0D0F"))
            isFillViewport = true
        }

        // ── Outer container ───────────────────────────────────────────────────
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity     = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(60), dp(20), dp(40))
        }
        scroll.addView(root)

        // ── Title: "App Crashed" ──────────────────────────────────────────────
        root.addView(TextView(this).apply {
            text      = "App Crashed"
            textSize  = 28f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity   = Gravity.CENTER
            alpha     = 0f
            tag       = "title"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(4) }
        })

        // ── Subtitle ──────────────────────────────────────────────────────────
        root.addView(TextView(this).apply {
            text      = "An unexpected error occurred"
            textSize  = 14f
            setTextColor(Color.parseColor("#99FFFFFF"))
            gravity   = Gravity.CENTER
            alpha     = 0f
            tag       = "subtitle"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(28) }
        })

        // ── Error type label ──────────────────────────────────────────────────
        root.addView(TextView(this).apply {
            text      = "EXCEPTION TYPE"
            textSize  = 11f
            setTextColor(Color.parseColor("#66FFFFFF"))
            letterSpacing = 0.1f
            alpha     = 0f
            tag       = "card"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(4) }
        })

        // ── Error type value ──────────────────────────────────────────────────
        tvErrorType = TextView(this).apply {
            text      = "Unknown"
            textSize  = 20f
            setTypeface(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(Color.parseColor("#FF5252"))
            alpha     = 0f
            tag       = "card"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(16) }
        }
        root.addView(tvErrorType)

        // ── Location label ────────────────────────────────────────────────────
        root.addView(TextView(this).apply {
            text      = "LOCATION"
            textSize  = 11f
            setTextColor(Color.parseColor("#66FFFFFF"))
            letterSpacing = 0.1f
            alpha     = 0f
            tag       = "card"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(4) }
        })

        // ── Error line ────────────────────────────────────────────────────────
        tvErrorLine = TextView(this).apply {
            text      = "See full log below"
            textSize  = 13f
            setTypeface(Typeface.MONOSPACE)
            setTextColor(Color.parseColor("#CCFFFFFF"))
            maxLines  = 2
            ellipsize = android.text.TextUtils.TruncateAt.END
            alpha     = 0f
            tag       = "card"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(28) }
        }
        root.addView(tvErrorLine)

        // ── Log label ─────────────────────────────────────────────────────────
        root.addView(TextView(this).apply {
            text      = "FULL CRASH LOG"
            textSize  = 11f
            setTextColor(Color.parseColor("#66FFFFFF"))
            letterSpacing = 0.1f
            alpha     = 0f
            tag       = "log"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(6) }
        })

        // ── Log ScrollView ────────────────────────────────────────────────────
        val logScroll = ScrollView(this).apply {
            alpha = 0f
            tag   = "log"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(220)
            ).also { it.bottomMargin = dp(28) }
        }

        tvCrashLog = TextView(this).apply {
            text      = "Loading..."
            textSize  = 11f
            setTypeface(Typeface.MONOSPACE)
            setTextColor(Color.parseColor("#BBFFFFFF"))
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setLineSpacing(dp(3).toFloat(), 1f)
            movementMethod = ScrollingMovementMethod()
        }
        logScroll.addView(tvCrashLog)
        root.addView(logScroll)

        // ── Buttons row ───────────────────────────────────────────────────────
        val btnRow = LinearLayout(this).apply {
            orientation  = LinearLayout.HORIZONTAL
            gravity      = Gravity.CENTER
            weightSum    = 3f
            alpha        = 0f
            tag          = "buttons"
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).also { it.bottomMargin = dp(28) }
        }

        btnCopy    = makeButton("Copy",    Color.parseColor("#2979FF"))
        btnRestart = makeButton("Restart", Color.parseColor("#00C853"))
        btnClose   = makeButton("Close",   Color.parseColor("#FF5252"))

        listOf(btnCopy, btnRestart, btnClose).forEachIndexed { i, btn ->
            btn.layoutParams = LinearLayout.LayoutParams(0, dp(56), 1f).also {
                it.marginStart = if (i == 0) 0 else dp(6)
                it.marginEnd   = if (i == 2) 0 else dp(6)
            }
            btnRow.addView(btn)
        }
        root.addView(btnRow)

        // ── Footer ────────────────────────────────────────────────────────────
        root.addView(TextView(this).apply {
            text      = "CaromPredictor Crash Finder v1.0"
            textSize  = 11f
            setTextColor(Color.parseColor("#44FFFFFF"))
            gravity   = Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        })

        return scroll
    }

    // ── Button factory ────────────────────────────────────────────────────────
    private fun makeButton(label: String, color: Int): Button =
        Button(this).apply {
            text = label
            textSize = 13f
            setTextColor(Color.WHITE)
            setTypeface(typeface, Typeface.BOLD)
            setBackgroundColor(color)
        }

    // ── Parse crash log ───────────────────────────────────────────────────────
    private fun parseAndDisplay() {
        tvCrashLog.text = crashLog

        var errorType = "Unknown Error"
        var errorLine = ""

        for (raw in crashLog.lines()) {
            val line = raw.trim()
            when {
                line.startsWith("TYPE") -> {
                    val full = line.substringAfter(":").trim()
                    errorType = full.substringAfterLast('.')
                }
                (line.contains("at com.iwex") || line.contains("at com.miniclip"))
                        && errorLine.isEmpty() -> {
                    errorLine = line.removePrefix("at ")
                }
            }
        }

        tvErrorType.text = errorType
        tvErrorLine.text = errorLine.ifEmpty { "See full log below" }
    }

    // ── Button logic ──────────────────────────────────────────────────────────
    private fun setupButtons() {
        btnCopy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("CrashLog", crashLog))
            Toast.makeText(this, "Crash log copied!", Toast.LENGTH_SHORT).show()
        }

        btnRestart.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                packageManager.getLaunchIntentForPackage(pkgName)?.apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                }?.let { startActivity(it) }
                finish()
                android.os.Process.killProcess(android.os.Process.myPid())
            }, 250)
        }

        btnClose.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                finish()
                android.os.Process.killProcess(android.os.Process.myPid())
            }, 250)
        }
    }

    // ── Animations ────────────────────────────────────────────────────────────
    private fun runEntranceAnimation() {
        // Title + subtitle
        animateIn("title", 0)
        animateIn("subtitle", 80)
        // Error card block
        animateIn("card", 200)
        // Log
        animateIn("log", 320)
        // Buttons
        animateIn("buttons", 440)
    }

    private fun animateIn(tag: String, delayMs: Long) {
        val root = (window.decorView.findViewById<View>(android.R.id.content)
            .rootView as? ScrollView)?.getChildAt(0) as? LinearLayout
            ?: return

        for (i in 0 until root.childCount) {
            val v = root.getChildAt(i)
            if (v.tag == tag) {
                v.translationY = dp(40).toFloat()
                v.animate()
                    .alpha(1f)
                    .translationY(0f)
                    .setDuration(380)
                    .setStartDelay(delayMs)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            }
        }
    }

    companion object {
        const val EXTRA_CRASH_LOG = "crash_log"
        const val EXTRA_PACKAGE   = "package_name"
    }
}
