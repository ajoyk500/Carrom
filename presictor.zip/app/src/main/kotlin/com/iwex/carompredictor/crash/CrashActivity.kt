package com.iwex.carompredictor.crash

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.iwex.carompredictor.R
import com.iwex.carompredictor.databinding.ActivityCrashBinding

class CrashActivity : AppCompatActivity() {

    // ── ViewBinding ───────────────────────────────────────────────────────────
    private lateinit var binding: ActivityCrashBinding

    private var crashLog    = ""
    private var packageName = ""

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCrashBinding.inflate(layoutInflater)
        setContentView(binding.root)

        crashLog    = intent?.getStringExtra(EXTRA_CRASH_LOG)  ?: "No crash log available."
        packageName = intent?.getStringExtra(EXTRA_PACKAGE)    ?: getPackageName()

        parseAndDisplay()
        setupButtons()
        runEntranceAnimation()
    }

    // Back press blocked — user must pick an action
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() = Unit

    // ── Parse & Display ───────────────────────────────────────────────────────
    private fun parseAndDisplay() {
        binding.tvCrashLog.text = crashLog

        var errorType = "Unknown Error"
        var errorLine = ""

        for (raw in crashLog.lines()) {
            val line = raw.trim()
            when {
                line.startsWith("TYPE") -> {
                    val full = line.substringAfter(":").trim()
                    errorType = full.substringAfterLast('.')
                }
                (line.contains("at com.iwex") || line.contains("at com.miniclip"))
                        && errorLine.isEmpty() -> {
                    errorLine = line.removePrefix("at ")
                }
            }
        }

        binding.tvErrorType.text = errorType
        binding.tvErrorLine.text = errorLine.ifEmpty { "See full log below" }
    }

    // ── Buttons ───────────────────────────────────────────────────────────────
    private fun setupButtons() {
        // COPY
        binding.btnCopy.setOnClickListener {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("CrashLog", crashLog))
            showSnackbar("📋 Crash log copied to clipboard")
        }

        // RESTART
        binding.btnRestart.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                packageManager.getLaunchIntentForPackage(packageName)
                    ?.apply {
                        addFlags(
                            Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TASK
                        )
                    }
                    ?.let { startActivity(it) }
                finish()
                android.os.Process.killProcess(android.os.Process.myPid())
            }, 250)
        }

        // CLOSE
        binding.btnClose.setOnClickListener {
            Handler(Looper.getMainLooper()).postDelayed({
                finish()
                android.os.Process.killProcess(android.os.Process.myPid())
            }, 250)
        }
    }

    // ── Snackbar ──────────────────────────────────────────────────────────────
    private fun showSnackbar(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT)
            .setBackgroundTint(getColor(R.color.snackbar_bg))
            .setTextColor(getColor(R.color.snackbar_text))
            .show()
    }

    // ── Entrance Animation ────────────────────────────────────────────────────
    private fun runEntranceAnimation() {
        // Bug icon — scale + fade in with overshoot
        binding.imgBug.apply {
            alpha  = 0f; scaleX = 0.2f; scaleY = 0.2f
        }
        val iconSet = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(binding.imgBug, View.ALPHA,  0f, 1f),
                ObjectAnimator.ofFloat(binding.imgBug, View.SCALE_X, 0.2f, 1f),
                ObjectAnimator.ofFloat(binding.imgBug, View.SCALE_Y, 0.2f, 1f)
            )
            duration     = 500
            interpolator = OvershootInterpolator(1.8f)
        }

        // Title block — slide up
        binding.layoutTitles.apply { alpha = 0f; translationY = 40f }
        val titleAnim = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(binding.layoutTitles, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(binding.layoutTitles, View.TRANSLATION_Y, 40f, 0f)
            )
            duration     = 420
            startDelay   = 180
            interpolator = DecelerateInterpolator()
        }

        // Error card — slide up
        binding.cardError.apply { alpha = 0f; translationY = 60f }
        val cardAnim = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(binding.cardError, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(binding.cardError, View.TRANSLATION_Y, 60f, 0f)
            )
            duration     = 420
            startDelay   = 280
            interpolator = DecelerateInterpolator()
        }

        // Log box
        binding.cardLog.apply { alpha = 0f; translationY = 50f }
        val logAnim = AnimatorSet().apply {
            playTogether(
                ObjectAnimator.ofFloat(binding.cardLog, View.ALPHA, 0f, 1f),
                ObjectAnimator.ofFloat(binding.cardLog, View.TRANSLATION_Y, 50f, 0f)
            )
            duration     = 400
            startDelay   = 360
            interpolator = DecelerateInterpolator()
        }

        // Buttons — staggered
        listOf(binding.btnCopy, binding.btnRestart, binding.btnClose)
            .forEachIndexed { i, btn ->
                btn.alpha = 0f; btn.translationY = 40f
                btn.animate()
                    .alpha(1f).translationY(0f)
                    .setDuration(380)
                    .setStartDelay(460L + i * 80L)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
            }

        // Play all together
        AnimatorSet().apply {
            playTogether(iconSet, titleAnim, cardAnim, logAnim)
            start()
        }
    }

    companion object {
        const val EXTRA_CRASH_LOG = "crash_log"
        const val EXTRA_PACKAGE   = "package_name"
    }
}
