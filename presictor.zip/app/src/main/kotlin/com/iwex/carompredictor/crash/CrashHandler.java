package com.iwex.carompredictor.crash;

import android.content.Context;
import android.content.Intent;
import android.os.Build;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * CrashHandler — Global uncaught exception interceptor.
 * Install this in your Application class or any Activity.onCreate().
 *
 * Usage:
 *   CrashHandler.install(this);
 */
public class CrashHandler implements Thread.UncaughtExceptionHandler {

    private static final String TAG = "CrashHandler";

    private final Context            appContext;
    private final Thread.UncaughtExceptionHandler defaultHandler;

    // ── Singleton install ─────────────────────────────────────────────────────
    public static void install(Context context) {
        Thread.setDefaultUncaughtExceptionHandler(
            new CrashHandler(context.getApplicationContext())
        );
    }

    private CrashHandler(Context ctx) {
        this.appContext     = ctx;
        this.defaultHandler = Thread.getDefaultUncaughtExceptionHandler();
    }

    // ── Core handler ──────────────────────────────────────────────────────────
    @Override
    public void uncaughtException(Thread thread, Throwable throwable) {
        try {
            String crashLog = buildCrashReport(thread, throwable);

            Intent intent = new Intent(appContext, CrashActivity.class);
            intent.putExtra(CrashActivity.EXTRA_CRASH_LOG, crashLog);
            intent.putExtra(CrashActivity.EXTRA_PACKAGE,
                            appContext.getPackageName());
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TASK |
                            Intent.FLAG_ACTIVITY_CLEAR_TOP);
            appContext.startActivity(intent);

        } catch (Exception ignored) {
            // If we crash inside the crash handler, fall back to default
            if (defaultHandler != null)
                defaultHandler.uncaughtException(thread, throwable);
        }
        // Kill the app process so system doesn't show its own dialog
        android.os.Process.killProcess(android.os.Process.myPid());
        System.exit(1);
    }

    // ── Report builder ────────────────────────────────────────────────────────
    public static String buildCrashReport(Thread thread, Throwable throwable) {
        StringWriter sw  = new StringWriter();
        PrintWriter  pw  = new PrintWriter(sw);

        // ── Header
        String time = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",
                                            Locale.getDefault())
                          .format(new Date());
        pw.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        pw.println("  CRASH REPORT — CaromPredictor");
        pw.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        pw.println();

        // ── Time & Thread
        pw.println("TIME    : " + time);
        pw.println("THREAD  : " + thread.getName()
                              + " (id=" + thread.getId() + ")");
        pw.println();

        // ── Device Info
        pw.println("── DEVICE ───────────────────────────────");
        pw.println("BRAND   : " + Build.BRAND);
        pw.println("MODEL   : " + Build.MODEL);
        pw.println("ANDROID : " + Build.VERSION.RELEASE
                              + " (SDK " + Build.VERSION.SDK_INT + ")");
        pw.println("ABI     : " + Build.SUPPORTED_ABIS[0]);
        pw.println();

        // ── Exception
        pw.println("── EXCEPTION ────────────────────────────");
        pw.println("TYPE    : " + throwable.getClass().getName());
        pw.println("MESSAGE : " + throwable.getMessage());
        pw.println();

        // ── Stack Trace
        pw.println("── STACK TRACE ──────────────────────────");
        throwable.printStackTrace(pw);

        // ── Caused By chain
        Throwable cause = throwable.getCause();
        int depth = 0;
        while (cause != null && depth < 5) {
            pw.println();
            pw.println("── CAUSED BY ────────────────────────────");
            cause.printStackTrace(pw);
            cause = cause.getCause();
            depth++;
        }

        pw.println();
        pw.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
        pw.flush();
        return sw.toString();
    }
}
