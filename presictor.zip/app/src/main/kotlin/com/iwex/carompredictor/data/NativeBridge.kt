package com.iwex.carompredictor.data

object NativeBridge {

    init {
        System.loadLibrary("carompredictor")
    }

    external fun nativeInitialize(): Boolean
    external fun nativeSetTablePos(
        screenW: Float, screenH: Float,
        boardX: Float,  boardY: Float,
        boardW: Float,  boardH: Float
    ): Boolean
    external fun nativeGetShotResult(): FloatArray?
    external fun nativeExit()
}
