package com.iwex.carompredictor.presentation.activity

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.iwex.carompredictor.crash.CrashHandler
import com.iwex.carompredictor.presentation.service.PredictorService

class LauncherActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Install crash interceptor — must be first thing
        CrashHandler.install(this)
        checkAndLaunch()
    }

    override fun onResume() {
        super.onResume()
        // Re-check when user comes back from settings
    }

    private fun checkAndLaunch() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant overlay permission", Toast.LENGTH_LONG).show()
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivityForResult(intent, REQUEST_OVERLAY)
        } else {
            startPredictor()
            finish()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startPredictor()
            } else {
                Toast.makeText(this, "Overlay permission denied — cannot run", Toast.LENGTH_LONG).show()
            }
            finish()
        }
    }

    private fun startPredictor() {
        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels.toFloat()
        val screenH = metrics.heightPixels.toFloat()

        // Board = square, fills screen width, centered vertically
        val boardSize = screenW
        val boardX    = 0f
        val boardY    = (screenH - boardSize) / 2f

        val intent = PredictorService.newIntent(
            this, screenW, screenH, boardX, boardY, boardSize, boardSize
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    companion object {
        private const val REQUEST_OVERLAY = 1001
    }
}
