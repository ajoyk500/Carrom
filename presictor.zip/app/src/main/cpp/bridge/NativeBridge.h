// CaromPredictor - NativeBridge.h
#pragma once
#include <jni.h>

class NativeBridge {
public:
    static jint registerNativeMethods(JNIEnv* env);

    // Called from Kotlin
    static jfloatArray getShotResult(JNIEnv* env, jobject thiz);
    static jboolean    initializeNative(JNIEnv* env, jobject thiz);
    static jboolean    setTablePosition(JNIEnv* env, jobject thiz,
                                         jfloat screenW, jfloat screenH,
                                         jfloat boardX,  jfloat boardY,
                                         jfloat boardW,  jfloat boardH);
    static void        exitNative(JNIEnv* env, jobject thiz);
};
