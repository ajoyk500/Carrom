// CaromPredictor - NativeBridge.cpp
#include "NativeBridge.h"
#include "../mod/predictor/Prediction.h"
#include "../mod/memory/MemoryManager.h"
#include "../mod/data/table/TableProperties.h"
#include <thread>
#include <android/log.h>

#define TAG "CaromPredictor"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

static const char* kClassName = "com/iwex/carompredictor/data/NativeBridge";

// ── JNI implementations ───────────────────────────────────────────────────────

jboolean NativeBridge::initializeNative(JNIEnv*, jobject) {
    LOGI("initializeNative called");
    std::thread([]() {
        bool ok = MemoryManager::initialize();
        LOGI("MemoryManager::initialize = %d", ok);
    }).detach();
    return JNI_TRUE;
}

jboolean NativeBridge::setTablePosition(JNIEnv*, jobject,
                                          jfloat screenW, jfloat screenH,
                                          jfloat boardX,  jfloat boardY,
                                          jfloat boardW,  jfloat boardH) {
    LOGI("setTablePosition: screen=%.0fx%.0f board=%.0f,%.0f size=%.0fx%.0f",
         screenW, screenH, boardX, boardY, boardW, boardH);
    TableProperties::initialize(screenW, screenH, boardX, boardY, boardW, boardH);
    return JNI_TRUE;
}

jfloatArray NativeBridge::getShotResult(JNIEnv* env, jobject) {
    bool updated = gPrediction->determineShotResult();
    if (!updated) return nullptr;

    float* result = gPrediction->getShotResult();

    // Size: compute from first two floats
    int size = 2;
    if (result[0] > 0.5f) {
        int nBalls = (int)result[1];
        int idx    = 2;
        for (int i = 0; i < nBalls; i++) {
            idx++;          // ball index
            int nPts = (int)result[idx++];
            idx += nPts * 2;
        }
        size = idx;
    }
    // Add pocket section
    size += 1 + POCKET_COUNT * 3;

    jfloatArray arr = env->NewFloatArray(size);
    env->SetFloatArrayRegion(arr, 0, size, result);
    return arr;
}

void NativeBridge::exitNative(JNIEnv*, jobject) {
    LOGI("exitNative called");
}

// ── Method table ─────────────────────────────────────────────────────────────

static const JNINativeMethod kMethods[] = {
    { "nativeInitialize",    "()Z",                    (void*)NativeBridge::initializeNative    },
    { "nativeSetTablePos",   "(FFFFFF)Z",               (void*)NativeBridge::setTablePosition    },
    { "nativeGetShotResult", "()[F",                   (void*)NativeBridge::getShotResult       },
    { "nativeExit",          "()V",                    (void*)NativeBridge::exitNative          },
};

jint NativeBridge::registerNativeMethods(JNIEnv* env) {
    jclass cls = env->FindClass(kClassName);
    if (!cls) {
        LOGE("Class not found: %s", kClassName);
        return JNI_ERR;
    }
    return env->RegisterNatives(cls,
                                kMethods,
                                sizeof(kMethods) / sizeof(kMethods[0]));
}

// ── JNI_OnLoad ────────────────────────────────────────────────────────────────
extern "C"
JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM* vm, void*) {
    JNIEnv* env;
    vm->GetEnv((void**)&env, JNI_VERSION_1_6);
    if (NativeBridge::registerNativeMethods(env) != JNI_OK) {
        LOGE("Failed to register native methods");
        return JNI_ERR;
    }
    LOGI("CaromPredictor native library loaded ✓");
    return JNI_VERSION_1_6;
}
