// CaromPredictor - Point2D.h
#pragma once
#include <cmath>

struct Point2D {
    double x = 0.0;
    double y = 0.0;

    Point2D() = default;
    Point2D(double x, double y) : x(x), y(y) {}

    Point2D operator+(const Point2D& o) const { return {x + o.x, y + o.y}; }
    Point2D operator-(const Point2D& o) const { return {x - o.x, y - o.y}; }
    Point2D operator*(double s)         const { return {x * s,   y * s};   }

    bool operator==(const Point2D& o) const { return x == o.x && y == o.y; }
    bool operator!=(const Point2D& o) const { return !(*this == o); }

    double square()  const { return x * x + y * y; }
    double length()  const { return sqrt(square()); }
    void   nullify()       { x = 0.0; y = 0.0; }
    bool   isZero()  const { return x == 0.0 && y == 0.0; }
    bool   isNotZero() const { return !isZero(); }
};

struct Vector3D {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;

    void nullify() { x = y = z = 0.0; }
    bool isZero()    const { return x == 0.0 && y == 0.0 && z == 0.0; }
    bool isNotZero() const { return !isZero(); }
};

// Screen coordinate (pixels)
struct ScreenPoint {
    float x = 0.0f;
    float y = 0.0f;
};
