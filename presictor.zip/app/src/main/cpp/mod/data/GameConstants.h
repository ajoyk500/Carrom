// CaromPredictor - GameConstants.h
// Extracted from libgame-CARROM-GooglePlay-Gold-Release-Module-1378.so

#pragma once

// ── BALL TYPES (FieldEntity type field) ──────────────────────────────────────
enum BallType : int {
    STRIKER  = 0,
    BLACK    = 1,
    WHITE    = 2,
    QUEEN    = 3,
    ERR_TYPE = -1
};

// ── BALL STATE ────────────────────────────────────────────────────────────────
enum BallState : int {
    ON_TABLE  = 1,
    POCKETED  = 2,
    UNKNOWN   = 3,
    ERR_STATE = -1
};

// ── PLAYER ────────────────────────────────────────────────────────────────────
enum PlayerType : int {
    PLAYER_BLACK = 0,
    PLAYER_WHITE = 1
};

// ── BALL COUNTS ───────────────────────────────────────────────────────────────
constexpr int BLACK_PUCKS_COUNT = 9;
constexpr int WHITE_PUCKS_COUNT = 9;
constexpr int TOTAL_PUCKS_COUNT = 19; // 9 black + 9 white + 1 queen
constexpr int MAX_FIELD_OBJECTS = 20; // pucks + striker

// ── BALL RADIUS ───────────────────────────────────────────────────────────────
// Found at offset 0x11c4b8c in .so file
constexpr double BALL_RADIUS        = 6.4;
constexpr double BALL_RADIUS_SQ     = BALL_RADIUS * BALL_RADIUS;
constexpr double BALL_DIAMETER      = BALL_RADIUS * 2.0;
constexpr double BALL_DIAMETER_SQ   = BALL_DIAMETER * BALL_DIAMETER;

// ── TABLE DIMENSIONS ─────────────────────────────────────────────────────────
// Found at offsets 0x11c4ba8 and 0x11c4c0c in .so file
constexpr double TABLE_HALF_WIDTH   = 168.5;
constexpr double TABLE_HALF_HEIGHT  = 128.5;
constexpr double TABLE_WIDTH        = TABLE_HALF_WIDTH  * 2.0; // 337.0
constexpr double TABLE_HEIGHT       = TABLE_HALF_HEIGHT * 2.0; // 257.0

// ── TABLE BOUNDS (ball center limits) ────────────────────────────────────────
constexpr double TABLE_BOUND_LEFT   = -TABLE_HALF_WIDTH  + BALL_RADIUS;
constexpr double TABLE_BOUND_RIGHT  =  TABLE_HALF_WIDTH  - BALL_RADIUS;
constexpr double TABLE_BOUND_TOP    = -TABLE_HALF_HEIGHT + BALL_RADIUS;
constexpr double TABLE_BOUND_BOTTOM =  TABLE_HALF_HEIGHT - BALL_RADIUS;

// ── POCKETS ───────────────────────────────────────────────────────────────────
// Carrom has 4 corner pockets
constexpr int    POCKET_COUNT       = 4;
constexpr double POCKET_RADIUS      = 9.0;
constexpr double POCKET_RADIUS_SQ   = POCKET_RADIUS * POCKET_RADIUS;

// Corner pocket positions (X, Y)
// Top-Left, Top-Right, Bottom-Right, Bottom-Left
constexpr double POCKET_POSITIONS[4][2] = {
    { -TABLE_HALF_WIDTH,  -TABLE_HALF_HEIGHT }, // Top-Left
    {  TABLE_HALF_WIDTH,  -TABLE_HALF_HEIGHT }, // Top-Right
    {  TABLE_HALF_WIDTH,   TABLE_HALF_HEIGHT }, // Bottom-Right
    { -TABLE_HALF_WIDTH,   TABLE_HALF_HEIGHT }  // Bottom-Left
};

// ── PHYSICS CONSTANTS ─────────────────────────────────────────────────────────
// Found at offset 0x11c4c20 in .so file
constexpr double TIME_PER_TICK      = 0.005;
constexpr double MIN_TIME           = 1E-11;

// Friction / damping (tuned for carrom feel)
constexpr double FRICTION_FACTOR    = 0.992;
constexpr double RESTITUTION        = 0.804; // cushion bounce factor

// ── SHOT RESULT BUFFER ────────────────────────────────────────────────────────
constexpr int MAX_SHOT_RESULT_SIZE  = 20000;

// ── ANGLE CONSTANTS ───────────────────────────────────────────────────────────
// Found at offset 0x11c4bbc (PI) and 0x11c4c1c (step) in .so file
constexpr double PI                 = 3.14159265358979;
constexpr double PI_HALF            = PI / 2.0;
constexpr double TWO_PI             = PI * 2.0;
constexpr double MIN_ANGLE_STEP     = 0.01745; // ~1 degree in radians

// ── TABLE SHAPE ───────────────────────────────────────────────────────────────
constexpr int TABLE_SHAPE_SIZE      = 40; // number of cushion segments
