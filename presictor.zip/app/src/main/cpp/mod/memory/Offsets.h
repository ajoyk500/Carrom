// CaromPredictor - Offsets.h
// Game: Carrom Pool by Miniclip
// .so : libgame-CARROM-GooglePlay-Gold-Release-Module-1378.so
// Arch: ARM64 (AArch64)

#pragma once

namespace Offsets {

    using OFFSET = unsigned long; // 64-bit ARM

    // ── LIBRARY NAME ─────────────────────────────────────────────────────────
    // Found via /proc/self/maps scan
    static constexpr const char* GAME_LIB_NAME =
        "libgame-CARROM-GooglePlay-Gold-Release-Module";

    // ── GLOBAL INSTANCES (RVA from module base) ───────────────────────────────
    // Found via readelf symbol scan of .so file
    namespace Globals {
        // Cocos2d shared director — entry point to whole scene graph
        constexpr OFFSET SharedDirector       = 0x2CF4370;

        // Gameplay state protobuf instances (live data)
        constexpr OFFSET PuckState            = 0x2C891D8;
        constexpr OFFSET StrikerState         = 0x2C891A8;
        constexpr OFFSET ShotOutcome          = 0x2C89310;
        constexpr OFFSET AimEvent             = 0x2C89240;
        constexpr OFFSET TableState           = 0x2C89160;

        // Queen / puck pocket events
        constexpr OFFSET QueenPocketed        = 0x2C89720;
        constexpr OFFSET PuckPotted           = 0x2C896D8;

        // Striker default instance
        constexpr OFFSET StrikerInstance      = 0x2C89A50;

        // Physics debug flag (useful for testing)
        constexpr OFFSET PhysicsDebugEnabled  = 0x2CD4B61;
    }

    // ── FIELD ENTITY STRUCT OFFSETS ──────────────────────────────────────────
    // Decoded from ObjC type encoding: FieldEntity=iddddddB
    // i=int(4), d=double(8 each), B=bool(1)
    namespace FieldEntity {
        constexpr OFFSET Type        = 0x00; // int   — BallType enum
        // padding 4 bytes here (alignment)
        constexpr OFFSET X           = 0x08; // double — world X position
        constexpr OFFSET Y           = 0x10; // double — world Y position
        constexpr OFFSET Radius      = 0x18; // double — ball radius
        constexpr OFFSET Angle       = 0x20; // double — current rotation angle
        constexpr OFFSET VelocityX   = 0x28; // double — X velocity
        constexpr OFFSET VelocityY   = 0x30; // double — Y velocity
        constexpr OFFSET OnTable     = 0x38; // bool   — is active on board
    }

    // ── STRIKER STRUCT OFFSETS ────────────────────────────────────────────────
    // Decoded from StrikerEntity structure + StrikerState proto
    namespace Striker {
        constexpr OFFSET X           = 0x08; // double — striker X position
        constexpr OFFSET Y           = 0x10; // double — striker Y position
        constexpr OFFSET AimAngle    = 0x18; // double — aim direction (radians)
        constexpr OFFSET Power       = 0x20; // double — shot power (0.0 - 1.0)
        constexpr OFFSET IsMoving    = 0x28; // bool   — currently in motion
    }

    // ── GAME MANAGER OFFSETS ─────────────────────────────────────────────────
    // CarromGameManager internal fields
    namespace CarromGameManager {
        constexpr OFFSET FieldObjects = 0x2A8; // pointer to puck array
        constexpr OFFSET PuckCount    = 0x2AC; // int — active puck count
        constexpr OFFSET GameState    = 0x300; // int — current game state
        constexpr OFFSET PlayerTurn   = 0x304; // int — whose turn (0/1)
        constexpr OFFSET PlayerType   = 0x308; // int — local player type
    }

    // ── AIM EVENT PROTO OFFSETS ───────────────────────────────────────────────
    // From _gameplay_aim_event_default_instance_ structure
    namespace AimEvent {
        constexpr OFFSET Angle       = 0x10; // double — aim angle radians
        constexpr OFFSET Power       = 0x18; // double — shot power
        constexpr OFFSET SpinX       = 0x20; // double — horizontal spin
        constexpr OFFSET SpinY       = 0x28; // double — vertical spin
    }

    // ── MENU STATE ────────────────────────────────────────────────────────────
    namespace MenuManager {
        constexpr OFFSET StateManager = 0x284; // pointer to state manager
    }

} // namespace Offsets
