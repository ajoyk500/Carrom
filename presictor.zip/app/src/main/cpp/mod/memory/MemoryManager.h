// CaromPredictor - MemoryManager.h
#pragma once
#include <cstdint>
#include "../data/type/Point2D.h"
#include "../data/GameConstants.h"

using ADDRESS = uintptr_t;

class MemoryManager {
public:
    static ADDRESS gameModuleBase;

    static bool    initialize();
    static ADDRESS findModuleBase(const char* name);

    // Generic typed read
    template<typename T>
    static T read(ADDRESS addr) {
        return *reinterpret_cast<T*>(addr);
    }

    // ── Submodules ────────────────────────────────────────────────────────────
    struct FieldObjects {
        static ADDRESS  listBase;          // pointer to array of FieldEntity*
        static int      count;

        static void     initialize(ADDRESS gameManagerAddr);
        static void     refresh();         // re-read positions each frame
        static int      getPuckCount();
        static Point2D  getPuckPosition(int index);
        static int      getPuckType(int index);
        static bool     isPuckOnTable(int index);
        static Point2D  getQueenPosition();
        static bool     isQueenOnTable();
    };

    struct StrikerInfo {
        static ADDRESS  base;

        static void     initialize(ADDRESS gameManagerAddr);
        static Point2D  getPosition();
        static double   getAimAngle();
        static double   getShotPower();
        static bool     isMoving();
    };

    struct GameState {
        static ADDRESS  base;

        static void     initialize(ADDRESS gameManagerAddr);
        static bool     isInGame();
        static int      getPlayerTurn();    // 0 = black, 1 = white
        static int      getLocalPlayer();
    };
};
