// CaromPredictor - Prediction.h
#pragma once
#include "../data/GameConstants.h"
#include "../data/type/Point2D.h"
#include "../data/table/TableProperties.h"
#include <vector>

class Prediction {
public:
    // Call every frame — returns float array for Java layer
    // Format: [drawLines, nBalls, ball0_index, ball0_nPts, x0,y0,x1,y1,..., drawPockets, p0_hit,p0x,p0y, ...]
    float* getShotResult();
    bool   determineShotResult();
    bool   mockPredictShotResult(); // for testing without game

    static float shotResult[MAX_SHOT_RESULT_SIZE];
    static bool  pocketHit[POCKET_COUNT]; // which pockets a ball entered

private:
    // ── Inner types ────────────────────────────────────────────────────────
    struct Ball {
        int     index        = 0;
        int     type         = 0;      // BallType
        bool    onTable      = true;
        bool    originalOnTable = true;
        Point2D initialPosition;
        Point2D predictedPosition;
        Point2D velocity;
        Vector3D spin;
        std::vector<Point2D> positions;

        bool isMovingOrSpinning() const;
        void move(double time);
        void calcVelocity();
        void calcVelocityPostCollision(double angle);

        // Collision detection
        bool findPocketEntry();
        bool isBallBallCollision(double* time, Ball& other) const;
        bool willHitCushion(const double* time) const;
        void findCushionCollision(void* sceneData, double* time);
        bool isBallLineCollision(double* t, const Point2D& a, const Point2D& b) const;
        bool isBallPointCollision(double* t, const Point2D& pt) const;
    };

    struct Collision {
        enum class Type { NONE, BALL, LINE, POINT };
        bool   valid  = false;
        Type   type   = Type::NONE;
        Ball*  ballA  = nullptr;
        Ball*  ballB  = nullptr;
        double angle  = 0.0;
        Point2D point;
        Ball*  firstHitBall = nullptr; // first non-striker ball cue hit
    };

    struct SceneData {
        int       ballsCount = 0;
        Ball      balls[MAX_FIELD_OBJECTS];
        Collision collision;
        bool      shotValid  = false; // cue hit correct ball?
    };

    SceneData guiData;
    int       shotResultSize = 0;

    // Simulation steps
    void initBalls();
    void initStriker(double angle, double power);
    void simulateBalls();
    void handleCollision();
    void handleBallBallCollision();
    void calculateShotResultSize();

    // Mock (test) data
    void mockInitBalls();
};
