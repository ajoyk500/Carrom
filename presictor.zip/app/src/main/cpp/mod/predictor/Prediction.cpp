// CaromPredictor - Prediction.cpp
#include "Prediction.h"
#include "../memory/MemoryManager.h"
#include <cmath>
#include <array>

static Prediction gPredictionObj;
Prediction* gPrediction = &gPredictionObj;

float Prediction::shotResult[MAX_SHOT_RESULT_SIZE];
bool  Prediction::pocketHit[POCKET_COUNT];

static double sPrevAngle = 0.0;
static double sPrevPower = 0.0;

// ── Physics tuning constants (from .so analysis) ─────────────────────────────
static constexpr double kFrictionA    = 0.992;   // rolling friction per tick
static constexpr double kRestitution  = 0.804;   // cushion energy retention
static constexpr double kSpinDecay    = 9.8 * TIME_PER_TICK;
static constexpr double kMinVelocity  = 1E-4;

// ═══════════════════════════════════════════════════════════════════════════════
//  PUBLIC
// ═══════════════════════════════════════════════════════════════════════════════

bool Prediction::determineShotResult() {
    if (!MemoryManager::GameState::isInGame()) return false;

    double angle = MemoryManager::StrikerInfo::getAimAngle();
    double power = MemoryManager::StrikerInfo::getShotPower();

    if (angle == sPrevAngle && power == sPrevPower) return false;
    sPrevAngle = angle;
    sPrevPower = power;

    initBalls();
    initStriker(angle, power);

    for (bool& ph : pocketHit) ph = false;
    guiData.collision.firstHitBall = nullptr;
    guiData.collision.valid        = false;

    simulateBalls();
    return true;
}

float* Prediction::getShotResult() {
    calculateShotResultSize();
    int idx = 0;

    // Section 1 — trajectory lines
    shotResult[idx++] = 1.0f; // always draw lines
    int nBallsIdx = idx;
    shotResult[idx++] = 0.0f; // placeholder: number of moving balls

    for (int i = 0; i < guiData.ballsCount; i++) {
        Ball& b = guiData.balls[i];
        if (b.initialPosition == b.predictedPosition) continue;
        shotResult[nBallsIdx] += 1.0f;
        shotResult[idx++] = (float)b.index;
        shotResult[idx++] = (float)b.positions.size();
        for (auto& pos : b.positions) {
            ScreenPoint sp = TableProperties::worldToScreen(pos);
            shotResult[idx++] = sp.x;
            shotResult[idx++] = sp.y;
        }
    }

    // Section 2 — pocket indicators (which pockets a ball went into)
    shotResult[idx++] = 1.0f; // draw pocket indicators
    ScreenPoint* pocketsSP = TableProperties::getPocketsInScreen();
    for (int i = 0; i < POCKET_COUNT; i++) {
        shotResult[idx++] = pocketHit[i] ? 1.0f : 0.0f;
        shotResult[idx++] = pocketsSP[i].x;
        shotResult[idx++] = pocketsSP[i].y;
    }

    return shotResult;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PRIVATE — INIT
// ═══════════════════════════════════════════════════════════════════════════════

void Prediction::initBalls() {
    guiData.ballsCount = MemoryManager::FieldObjects::getPuckCount() + 1; // +1 striker
    if (guiData.ballsCount > MAX_FIELD_OBJECTS) guiData.ballsCount = MAX_FIELD_OBJECTS;

    // Index 0 = striker
    Ball& striker = guiData.balls[0];
    striker.index           = 0;
    striker.type            = BallType::STRIKER;
    striker.onTable         = true;
    striker.originalOnTable = true;
    striker.initialPosition = MemoryManager::StrikerInfo::getPosition();
    striker.predictedPosition = striker.initialPosition;
    striker.velocity.nullify();
    striker.spin.nullify();
    striker.positions.clear();
    striker.positions.reserve(30);
    striker.positions.push_back(striker.initialPosition);

    // Indices 1..N = pucks
    int puckCount = guiData.ballsCount - 1;
    for (int i = 0; i < puckCount; i++) {
        Ball& b = guiData.balls[i + 1];
        b.index           = i + 1;
        b.type            = MemoryManager::FieldObjects::getPuckType(i);
        b.onTable         = MemoryManager::FieldObjects::isPuckOnTable(i);
        b.originalOnTable = b.onTable;
        b.initialPosition = MemoryManager::FieldObjects::getPuckPosition(i);
        b.predictedPosition = b.initialPosition;
        b.velocity.nullify();
        b.spin.nullify();
        b.positions.clear();
        b.positions.reserve(15);
        b.positions.push_back(b.initialPosition);
    }
}

void Prediction::initStriker(double angle, double power) {
    // Scale power: game power 0-1 → internal velocity units
    double speed = power * 900.0;
    Ball& striker = guiData.balls[0];
    striker.velocity.x = speed * cos(angle);
    striker.velocity.y = speed * sin(angle);

    double spinFactor   = speed / BALL_RADIUS;
    striker.spin.x      = -sin(angle) * spinFactor * 0.3;
    striker.spin.y      =  cos(angle) * spinFactor * 0.3;
    striker.spin.z      = 0.0;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  PRIVATE — SIMULATION
// ═══════════════════════════════════════════════════════════════════════════════

void Prediction::simulateBalls() {
    bool anyMoving;
    do {
        double tick = TIME_PER_TICK;
        do {
            double subTick = tick;
            guiData.collision.valid = false;

            // Find earliest collision this sub-tick
            for (int i = 0; i < guiData.ballsCount; i++) {
                Ball& b = guiData.balls[i];
                if (!b.onTable) continue;

                // Ball-ball
                for (int j = i + 1; j < guiData.ballsCount; j++) {
                    Ball& other = guiData.balls[j];
                    if (!other.onTable) continue;
                    if (b.isBallBallCollision(&subTick, other)) {
                        guiData.collision.valid = true;
                        guiData.collision.type  = Collision::Type::BALL;
                        guiData.collision.ballA = &b;
                        guiData.collision.ballB = &other;
                    }
                }

                // Cushion
                if (b.willHitCushion(&subTick)) {
                    b.findCushionCollision(&guiData, &subTick);
                }
            }

            // Move all balls to collision point
            for (int i = 0; i < guiData.ballsCount; i++) {
                Ball& b = guiData.balls[i];
                if (b.onTable && b.isMovingOrSpinning()) b.move(subTick);
            }

            if (guiData.collision.valid) handleCollision();

            tick -= subTick;
        } while (tick > MIN_TIME);

        // Per-tick velocity update
        anyMoving = false;
        for (int i = 0; i < guiData.ballsCount; i++) {
            Ball& b = guiData.balls[i];
            if (!b.onTable) continue;

            // Check pocket entry
            if (b.findPocketEntry()) continue;

            b.calcVelocity();
            if (b.isMovingOrSpinning()) anyMoving = true;
        }
    } while (anyMoving);

    // Push final predicted positions
    for (int i = 0; i < guiData.ballsCount; i++) {
        Ball& b = guiData.balls[i];
        if (b.positions.empty() || b.positions.back() != b.predictedPosition)
            b.positions.push_back(b.predictedPosition);
    }
}

void Prediction::handleCollision() {
    if (!guiData.collision.ballA) return;
    Ball& ballA = *guiData.collision.ballA;

    ballA.positions.push_back(ballA.predictedPosition);

    switch (guiData.collision.type) {
        case Collision::Type::BALL:
            handleBallBallCollision();
            if (guiData.collision.ballB) {
                guiData.collision.ballB->positions.push_back(
                    guiData.collision.ballB->predictedPosition);
                // Record first puck the striker hits
                if (ballA.type == BallType::STRIKER &&
                    guiData.collision.firstHitBall == nullptr)
                    guiData.collision.firstHitBall = guiData.collision.ballB;
            }
            break;

        case Collision::Type::LINE:
        case Collision::Type::POINT:
            ballA.calcVelocityPostCollision(guiData.collision.angle);
            break;

        default: break;
    }
}

void Prediction::handleBallBallCollision() {
    Ball& A = *guiData.collision.ballA;
    Ball& B = *guiData.collision.ballB;

    Point2D relPos  = A.predictedPosition - B.predictedPosition;
    double  invDist = 1.0 / sqrt(relPos.square());
    Point2D normal  = relPos * invDist;

    double vA = A.velocity.x * normal.x + A.velocity.y * normal.y;
    double vB = B.velocity.x * normal.x + B.velocity.y * normal.y;

    Point2D dvA = normal * vA;
    Point2D dvB = normal * vB;

    A.velocity.x = dvB.x - (dvA.x - A.velocity.x);
    A.velocity.y = dvB.y - (dvA.y - A.velocity.y);
    B.velocity.x = dvA.x - (dvB.x - B.velocity.x);
    B.velocity.y = dvA.y - (dvB.y - B.velocity.y);
}

void Prediction::calculateShotResultSize() {
    shotResultSize = 2; // drawLines flag + nBalls
    for (int i = 0; i < guiData.ballsCount; i++) {
        Ball& b = guiData.balls[i];
        if (b.initialPosition != b.predictedPosition)
            shotResultSize += (int)b.positions.size() * 2 + 3; // index,nPts,x,y...
    }
    shotResultSize += 1 + POCKET_COUNT * 3; // drawPockets + per-pocket data
}

// ═══════════════════════════════════════════════════════════════════════════════
//  BALL METHODS
// ═══════════════════════════════════════════════════════════════════════════════

bool Prediction::Ball::isMovingOrSpinning() const {
    return velocity.isNotZero() || spin.isNotZero();
}

void Prediction::Ball::move(double time) {
    predictedPosition.x += velocity.x * time;
    predictedPosition.y += velocity.y * time;
    positions.push_back(predictedPosition);
}

void Prediction::Ball::calcVelocity() {
    if (!isMovingOrSpinning()) return;

    double speed = sqrt(velocity.x * velocity.x + velocity.y * velocity.y);
    if (speed < kMinVelocity) {
        velocity.nullify();
        spin.nullify();
        return;
    }

    // Apply rolling friction
    velocity.x *= kFrictionA;
    velocity.y *= kFrictionA;

    // Spin decay
    spin.z = (spin.z > 0.0)
        ? fmax(spin.z - kSpinDecay, 0.0)
        : fmin(spin.z + kSpinDecay, 0.0);
}

void Prediction::Ball::calcVelocityPostCollision(double angle) {
    double ac = cos(angle), as = sin(angle);
    double vx =  ac * velocity.x - as * velocity.y;
    double vy =  as * velocity.x + ac * velocity.y;

    double newVx =  vx;
    double newVy = -vy * kRestitution;

    velocity.x = ac * newVx - as * newVy;
    velocity.y = as * newVx + ac * newVy;
}

bool Prediction::Ball::findPocketEntry() {
    const Point2D* pockets = TableProperties::getPockets();
    for (int i = 0; i < POCKET_COUNT; i++) {
        double dx = pockets[i].x - predictedPosition.x;
        double dy = pockets[i].y - predictedPosition.y;
        if (dx*dx + dy*dy < POCKET_RADIUS_SQ) {
            onTable = false;
            velocity.nullify();
            spin.nullify();
            Prediction::pocketHit[i] = true;
            return true;
        }
    }
    return false;
}

bool Prediction::Ball::isBallBallCollision(double* time, Ball& other) const {
    Point2D relPos = other.predictedPosition - predictedPosition;
    Point2D relVel = other.velocity - velocity;

    double dot = relPos.x * relVel.x + relPos.y * relVel.y;
    if (dot >= 0.0) return false;

    double velSq  = relVel.square();
    if (velSq < MIN_TIME) return false;

    double posSq  = relPos.square();
    double disc   = dot * dot - velSq * (posSq - BALL_DIAMETER_SQ);
    if (disc < 0.0) return false;

    double t = (-dot - sqrt(disc)) / velSq;
    if (t < 0.0 || t > *time) return false;

    *time = t;
    return true;
}

bool Prediction::Ball::willHitCushion(const double* time) const {
    double px = predictedPosition.x + velocity.x * (*time);
    double py = predictedPosition.y + velocity.y * (*time);
    return (px < TABLE_BOUND_LEFT  || px > TABLE_BOUND_RIGHT ||
            py < TABLE_BOUND_TOP   || py > TABLE_BOUND_BOTTOM);
}

void Prediction::Ball::findCushionCollision(void* pData, double* time) {
    auto* data       = reinterpret_cast<Prediction::SceneData*>(pData);
    const Point2D* shape = TableProperties::getTableShape();

    for (int i = 0; i < TABLE_SHAPE_SIZE; i++) {
        const Point2D& A = shape[i];
        const Point2D& B = shape[(i + 1) % TABLE_SHAPE_SIZE];

        if (isBallLineCollision(time, A, B)) {
            double dx = B.x - A.x, dy = B.y - A.y;
            double len = sqrt(dx*dx + dy*dy);
            data->collision.valid  = true;
            data->collision.type   = Collision::Type::LINE;
            data->collision.ballA  = this;
            data->collision.angle  = -atan2(dy / len, dx / len);
        } else if (isBallPointCollision(time, A)) {
            Point2D delta = { A.y - predictedPosition.y,
                            -(A.x - predictedPosition.x) };
            data->collision.valid  = true;
            data->collision.type   = Collision::Type::POINT;
            data->collision.ballA  = this;
            data->collision.point  = A;
            data->collision.angle  = -atan2(delta.y, delta.x);
        }
    }
}

bool Prediction::Ball::isBallLineCollision(double* t,
                                            const Point2D& A,
                                            const Point2D& B) const {
    if (velocity.isZero()) return false;

    Point2D d  = B - A;
    double  dv = d.y * velocity.x - d.x * velocity.y;
    if (fabs(dv) < MIN_TIME) return false;

    double  len    = sqrt(d.square());
    double  invLen = 1.0 / len;
    double  offset = BALL_RADIUS * invLen;

    double  rx = predictedPosition.x - A.x - d.y * offset;
    double  ry = predictedPosition.y - A.y + d.x * offset;

    double  u  = (rx * (-velocity.y) - ry * (-velocity.x)) / dv;
    if (u <= 0.0 || u >= 1.0) return false;

    double  time = (d.x * ry - d.y * rx) / dv;
    if (time <= 0.0 || time - MIN_TIME > *t) return false;

    // Check approaching
    if (velocity.x * (d.y * invLen) + velocity.y * (-d.x * invLen) > 0.0)
        return false;

    *t = time;
    return true;
}

bool Prediction::Ball::isBallPointCollision(double* t, const Point2D& pt) const {
    Point2D d   = pt - predictedPosition;
    double  dot = -(velocity.x * d.x * 2.0 + velocity.y * d.y * 2.0);
    if (dot >= 0.0) return false;

    double velSq  = velocity.square();
    double distSq = d.square();
    double disc   = dot * dot - velSq * 4.0 * (distSq - BALL_RADIUS_SQ);
    if (disc < 0.0) return false;

    double time = (-dot - sqrt(disc)) / (velSq * 2.0);
    if (time < 0.0 || time - MIN_TIME > *t) return false;

    *t = time;
    return true;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  MOCK (for testing without game)
// ═══════════════════════════════════════════════════════════════════════════════

bool Prediction::mockPredictShotResult() {
    static int step = 0;
    double angle = (step++ % 362) * MIN_ANGLE_STEP;
    double power = 0.75;

    mockInitBalls();
    initStriker(angle, power);
    for (bool& ph : pocketHit) ph = false;
    guiData.collision.firstHitBall = nullptr;
    simulateBalls();
    return true;
}

void Prediction::mockInitBalls() {
    guiData.ballsCount = 10; // striker + 9 pucks for demo

    // Striker at bottom-center
    Ball& s = guiData.balls[0];
    s.index = 0; s.type = BallType::STRIKER;
    s.onTable = s.originalOnTable = true;
    s.initialPosition = s.predictedPosition = {0.0, 80.0};
    s.velocity.nullify(); s.spin.nullify();
    s.positions.clear(); s.positions.push_back(s.initialPosition);

    // Some pucks in classic triangle layout
    const Point2D puckPos[] = {
        {0.0,  -20.0}, {-8.0, -10.0}, { 8.0, -10.0},
        {-16.0, 0.0},  { 0.0,   0.0}, {16.0,   0.0},
        {-8.0,  10.0}, { 8.0,  10.0},
        {0.0,  -30.0}  // queen
    };
    const int puckTypes[] = {
        BLACK, BLACK, WHITE, WHITE, BLACK,
        WHITE, BLACK, WHITE, QUEEN
    };

    for (int i = 0; i < 9; i++) {
        Ball& b = guiData.balls[i + 1];
        b.index = i + 1;
        b.type  = puckTypes[i];
        b.onTable = b.originalOnTable = true;
        b.initialPosition = b.predictedPosition = puckPos[i];
        b.velocity.nullify(); b.spin.nullify();
        b.positions.clear(); b.positions.push_back(b.initialPosition);
    }
}
